import os


# def template_variable(request):
#     context = {'user': username, 'role': role}
#     return context

