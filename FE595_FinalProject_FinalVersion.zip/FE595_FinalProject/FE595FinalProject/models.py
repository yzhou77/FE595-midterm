from __future__ import unicode_literals
from django.db import models

# Create your models here.


class Comment(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField(max_length=300, blank=True)
    url = models.URLField(blank=True)
    text = models.TextField()
    image = models.ImageField(upload_to="./image", blank=True)
    created_time = models.DateTimeField(auto_now_add=True)
